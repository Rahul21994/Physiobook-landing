Goswami Rehab Journal Images — High Quality

38 original JPEG files, each 1024×1024 pixels.
These are the source journal images; card thumbnails and build-generated duplicates are not included.
